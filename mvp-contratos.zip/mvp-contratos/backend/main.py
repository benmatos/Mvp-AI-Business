from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uuid, os, shutil

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

documents_db = {}

class CheckResult(BaseModel):
    id: str
    label: str
    result: str
    confidence: float
    evidence: str

class DocumentResult(BaseModel):
    doc_id: str
    status: str
    checks: list[CheckResult]

UPLOAD_DIR = "storage"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.post("/documents")
async def upload_document(file: UploadFile = File(...)):
    doc_id = str(uuid.uuid4())
    file_path = os.path.join(UPLOAD_DIR, f"{doc_id}_{file.filename}")
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    documents_db[doc_id] = {"status": "uploaded", "filename": file.filename}
    return {"doc_id": doc_id, "filename": file.filename}

@app.post("/documents/{doc_id}/process")
async def process_document(doc_id: str):
    if doc_id not in documents_db:
        raise HTTPException(status_code=404, detail="Documento não encontrado")
    checks = [
        {"id": "vigencia", "label": "Vigência especificada", "result": "pass", "confidence": 0.92, "evidence": "01/01/2025 - 31/12/2025"},
        {"id": "partes", "label": "Partes identificadas", "result": "warn", "confidence": 0.65, "evidence": "Nome da empresa faltando CNPJ"},
        {"id": "foro", "label": "Foro definido", "result": "fail", "confidence": 0.88, "evidence": "Não encontrado"},
    ]
    documents_db[doc_id]["status"] = "processed"
    documents_db[doc_id]["checks"] = checks
    return {"doc_id": doc_id, "status": "processed", "checks": checks}

@app.get("/documents/{doc_id}/results", response_model=DocumentResult)
async def get_results(doc_id: str):
    if doc_id not in documents_db or documents_db[doc_id]["status"] != "processed":
        raise HTTPException(status_code=404, detail="Documento não processado ainda")
    return {"doc_id": doc_id, "status": "processed", "checks": documents_db[doc_id]["checks"]}
