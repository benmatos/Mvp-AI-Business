from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
import os
import shutil
import pytesseract
from pdf2image import convert_from_path
from PIL import Image

app = FastAPI()

# Habilitar CORS para permitir acesso do frontend React
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = "storage"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Simulação de checklist
checklist_items = [
    {"id": 1, "title": "Cláusula de Prazo", "required": True},
    {"id": 2, "title": "Cláusula de Rescisão", "required": True},
    {"id": 3, "title": "Assinatura das Partes", "required": True},
]

def extract_text_from_file(file_path: str) -> str:
    text = ""
    if file_path.lower().endswith(".pdf"):
        images = convert_from_path(file_path)
        for img in images:
            text += pytesseract.image_to_string(img, lang="por") + "\n"
    else:
        image = Image.open(file_path)
        text = pytesseract.image_to_string(image, lang="por")
    return text

@app.post("/upload/")
async def upload_file(file: UploadFile = File(...)):
    file_path = os.path.join(UPLOAD_DIR, file.filename)
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    # Extração de texto real via OCR
    extracted_text = extract_text_from_file(file_path)

    return {"filename": file.filename, "content": extracted_text}

@app.get("/checklist/{doc_id}")
async def analyze_document(doc_id: str):
    # Exemplo simples: verificar se palavras-chave aparecem no texto
    file_path = os.path.join(UPLOAD_DIR, doc_id)
    if not os.path.exists(file_path):
        return {"error": "Documento não encontrado"}

    extracted_text = extract_text_from_file(file_path)

    results = []
    for item in checklist_items:
        if item["title"].split()[1].lower() in extracted_text.lower():
            results.append({"item": item["title"], "status": "ok"})
        else:
            results.append({"item": item["title"], "status": "faltando"})
    return {"document": doc_id, "results": results}
