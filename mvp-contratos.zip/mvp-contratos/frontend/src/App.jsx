import { useState } from "react";
import UploadForm from "./components/UploadForm";
import DocumentList from "./components/DocumentList";
import ChecklistView from "./components/ChecklistView";

function App() {
  const [docId, setDocId] = useState(null);
  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <h1 className="text-2xl font-bold mb-4">MVP - Análise de Contratos</h1>
      {!docId ? (
        <>
          <UploadForm onUpload={setDocId} />
          <DocumentList onSelect={setDocId} />
        </>
      ) : (
        <ChecklistView docId={docId} onBack={() => setDocId(null)} />
      )}
    </div>
  );
}

export default App;
