const API_URL = "http://localhost:8000";

export async function uploadDocument(file) {
  const formData = new FormData();
  formData.append("file", file);
  const res = await fetch(`${API_URL}/documents`, { method: "POST", body: formData });
  return res.json();
}

export async function processDocument(docId) {
  const res = await fetch(`${API_URL}/documents/${docId}/process`, { method: "POST" });
  return res.json();
}

export async function getResults(docId) {
  const res = await fetch(`${API_URL}/documents/${docId}/results`);
  return res.json();
}
