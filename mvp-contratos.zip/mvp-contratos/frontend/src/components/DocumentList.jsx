export default function DocumentList({ onSelect }) {
  return (
    <div>
      <h2 className="text-lg font-semibold mb-2">Documentos (mock)</h2>
      <ul>
        <li>
          <button onClick={() => onSelect("mock-doc-1")} className="text-blue-600 underline">
            Documento de teste
          </button>
        </li>
      </ul>
    </div>
  );
}
