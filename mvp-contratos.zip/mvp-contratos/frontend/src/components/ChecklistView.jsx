import { useEffect, useState } from "react";
import { getResults } from "../api";

export default function ChecklistView({ docId, onBack }) {
  const [results, setResults] = useState(null);
  useEffect(() => { async function fetchData() { setResults(await getResults(docId)); } fetchData(); }, [docId]);
  if (!results) return <p>Carregando resultados...</p>;
  return (
    <div>
      <button onClick={onBack} className="mb-4 px-3 py-1 bg-gray-500 text-white rounded-lg">Voltar</button>
      <h2 className="text-xl font-semibold mb-4">Checklist</h2>
      <ul className="space-y-3">
        {results.checks.map((check) => (
          <li key={check.id} className={\`p-3 rounded-lg \${check.result==="pass"?"bg-green-200":check.result==="warn"?"bg-yellow-200":"bg-red-200"}\`}>
            <strong>{check.label}</strong> — {check.result.toUpperCase()}
            <p className="text-sm">Confiança: {Math.round(check.confidence * 100)}%</p>
            <p className="text-sm italic">Evidência: {check.evidence}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
