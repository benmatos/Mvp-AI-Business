import { useState } from "react";
import { uploadDocument, processDocument } from "../api";

export default function UploadForm({ onUpload }) {
  const [file, setFile] = useState(null);
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file) return;
    const data = await uploadDocument(file);
    await processDocument(data.doc_id);
    onUpload(data.doc_id);
  };
  return (
    <form onSubmit={handleSubmit} className="mb-6">
      <input type="file" onChange={(e) => setFile(e.target.files[0])} />
      <button type="submit" className="ml-2 px-4 py-2 bg-blue-600 text-white rounded-lg">
        Enviar
      </button>
    </form>
  );
}
